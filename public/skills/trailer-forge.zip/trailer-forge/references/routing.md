# trailer-forge routing — endpoints, schemas, fallbacks

**Probed live 2026-07-19.** The fal catalog churns monthly: re-run the probe ritual
before trusting anything here that is >30 days old, and always schema-probe the
exact endpoint before first generation in a session.

## Probe ritual

```bash
# FAL_KEY must be exported for generation; the probes below are public.
# existence
curl -s -o /dev/null -w "%{http_code}" "https://fal.ai/api/openapi/queue/openapi.json?endpoint_id=<endpoint>"
# input schema (params, enums, defaults, required)
curl -s "https://fal.ai/api/openapi/queue/openapi.json?endpoint_id=<endpoint>" | python3 -c "
import json,sys
spec=json.load(sys.stdin)
for n,s in spec.get('components',{}).get('schemas',{}).items():
    if 'input' in n.lower():
        for k,v in s.get('properties',{}).items(): print(k, v.get('enum'), v.get('default'))
        print('required:', s.get('required'))"
# catalog search when an ID 404s or you need the current family
curl -s "https://fal.ai/api/models?keywords=<term>" | python3 -c "import json,sys;[print(i['id'],'|',i['category']) for i in json.load(sys.stdin)['items']]"
```

## Primary routing (all verified 200 on 2026-07-19)

| Job | Endpoint | Key params (probed) | Notes |
|---|---|---|---|
| Keyframes / cast sheets | `bytedance/seedream/v5/pro/text-to-image` | `image_size:{width,height}` (2520×1080 for 21:9), `num_images:2`, `output_format:"png"`, `enable_safety_checker:false` | 2 variants per call = pick without re-roll |
| Keyframe surgical fix | `bytedance/seedream/v5/pro/edit` | up to 10 reference images, region-precise | fix a face/texture, keep the frame |
| Animate (one-off shots) | `bytedance/seedance-2.0/image-to-video` | `image_url`, `prompt`, `duration:"4".."15"`, `resolution:480p/720p/1080p/4k`, `aspect_ratio:auto/21:9/16:9/4:3/1:1/3:4/9:16`, `generate_audio:false`, `bitrate_mode:"high"` | #1 both i2v arenas (corpus 2026-07); ~2206×946 out at 1080p/21:9, 24fps |
| Animate (recurring subjects) | `bytedance/seedance-2.0/reference-to-video` | `prompt` (req), `image_urls` (cast sheet, ≤9), `video_urls`, `audio_urls`, same res/duration/aspect enums | THE continuity mechanism — feed cast sheet + anchor phrase |
| Video edit (fix w/o re-roll) | `fal-ai/wan/v2.7/edit-video` | probe before use | primary fal-native v2v; corpus: Wan 2.7 = value + edit-video |
| Video edit alt | `fal-ai/kling-video/o3/pro/video-to-video/edit` | probe before use | when Wan edit misses; also `o3/standard/...` |
| Music | `fal-ai/elevenlabs/music` | `prompt`, `music_length_ms`, `force_instrumental:true`, `output_format:"pcm_44100"` | **PCM = lossless rule satisfied**; CDN delivers .wav |
| VO | `fal-ai/elevenlabs/tts/eleven-v3` | `text`, `voice` (name, e.g. "Brian"), `stability` | v3 audio tags (`[whispers]`) usually process — vo_qa.py catches literal reads |
| VO QA (ASR) | `fal-ai/wizper` | `audio_url` | whisper-class; used by `bin/vo_qa.py` |
| SFX | `fal-ai/elevenlabs/sound-effects` | `text` (req), `duration_seconds` | **was 400ing upstream 2026-07-19 (twice, minimal params)** — try once, then synth fallback below |
| Video upscale/misc | search catalog | — | `fal-ai/ffmpeg-api/*` exists server-side; local ffmpeg preferred |

Video fallback if Seedance misfires on a shot class: `fal-ai/kling-video/v3/pro/image-to-video`
(verified 200; negative_prompt support, hero-shot strength per corpus).

**2026-07-24: Seedance 422s photoreal-face images.** Any i2v/ref2v with a close-up realistic
human face fails `partner_validation_failed` ("likenesses of real people") — with OR without
audio_urls; tightened since 07-19 (earlier person clips passed). Distant/small people in
frame still pass. `fal-ai/sync-lipsync/v3/image-to-video` (still + audio → talking character)
works mechanically — exact keyframe framing, bit-exact audio mux, natural gestures — BUT
**2026-07-24 verdict: ElevenLabs premade-voice TTS as the character dialogue source was
rejected as unusable** (flat acting; written dialect + neutral voice = uncanny). For
talking characters use NATIVE-audio video gen: `fal-ai/kling-video/v3/pro/image-to-video`
(generate_audio, durations 3–15s, start_image keeps framing, element-bound `voice_id` =
cross-clip voice consistency; lowercase English speech in prompt) or `fal-ai/veo3.1/
image-to-video` (top acting; 4/6/8s only; auto_fix + safety_tolerance params). Direct
accent/delivery in the prompt. The user must ear-check one voice test before batching
heads. Seedance ref2v `audio_urls` exists in-schema but is unusable for realistic faces.

## Execution

`bin/gen.py` (stdlib): submits to `https://queue.fal.run/<endpoint>`, polls returned
`status_url`, downloads outputs, and **writes every payload JSON to `payloads/`
beside its output** — any shot re-rolls from its file without re-deriving anything.
Spec files: `{"kind": "images"|"video"|"audio", "out_dir", "manifest", "jobs":[{name,endpoint,payload}]}`.
Uploads: `python3 -c "import fal_client; print(fal_client.upload_file('<path>'))"`
(`pip install fal-client`; if it lives in a venv, use that venv's python — the same
interpreter `FAL_PYTHON` points at for vo_qa.py).

## Fallback map (all battle-tested)

- **SFX endpoint 400s** → synthesize: brown noise lowpassed + 31 Hz sine w/ tremolo,
  fade envelope, alimiter (exact graph in pipeline.md §8). Under a score impact it is
  indistinguishable from a generated rumble.
- **No drawtext in Homebrew ffmpeg** → `bin/title_card.py` (PIL text PNG + overlay
  with alpha fades). Default font is macOS Futura
  (`/System/Library/Fonts/Supplemental/Futura.ttc`); on other systems pass `--font`.
- **Endpoint 404** → catalog search; model families rename (`bytedance/seedream/v4/*`
  → `/v5/pro/*` happened between corpus fetch and today).
- **Two failures on one axis** → change mechanics (different endpoint/layer/tool),
  never a third rephrase. (frontier-video-prompting escape rule.)
- **grain × CRF16 = huge files** → keep CRF16 as archival master, ship CRF21.

## Pricing signal (estimate; exact = fal dashboard)

Reference-run actuals (7 shots, ~54 s of video), one pass: 14 Seedream images
≈ $0.5–1 · 54 s Seedance 1080p ≈ $22–38 · music + 7 TTS ≈ $1.5–2 →
**≈$25–40 per ~60 s trailer**. 4K roughly 2× the clip cost; state the estimate in
every delivery.
