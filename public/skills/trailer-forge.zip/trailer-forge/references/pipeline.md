# trailer-forge pipeline — stage detail

Commands assume `FAL_KEY` is exported and these shell vars are set:

```bash
F=<absolute path to this skill folder>            # bin/ + templates/ live here
H="${TRAILER_FORGE_HOME:-$HOME/trailer-forge}"    # durable project home
P="$H/projects/<slug>"
```

gen.py lives in `$F/bin` and works from any cwd if the spec uses absolute paths
(scaffold writes them absolute).

## 0 · Scaffold

```bash
$F/bin/scaffold.sh <slug>
```

## 1 · Style bible (PLAN.md)

Absorb every ref image/URL the user provides — describe each ref's treatment
exhaustively (stock, palette, texture, era, lens) as named **registers**, plus
**unifiers** applied to every shot (grain/scratches/halation/matte/scale-contrast).
Registers may differ wildly (etching vs 70mm vs Kodachrome) — the unifiers and the
recurring subjects are what bind the film. If no refs: propose a register set from
the logline and state it as an assumption in PLAN.md.

## 2 · Beats

Events with causality, 6–9 shots for ~60 s. Per shot: register, duration (4–15 s),
the ONE novel element (motion event), the ONE camera move, engine (i2v | ref2v).
Reserve the biggest novel element for a late money shot on a **locked camera** —
static frame makes a big event legible and cheap for the model. Write VO now
(sparse, ≤6 lines; respell phonetic risks — heteronyms, numbers, odd names — so
TTS reads them right; a lyric-phonetics skill helps here if installed).

## 3 · Cast sheets (continuity is first-class — do this BEFORE keyframes)

**Step 0 — real reference files first.** If the user supplied images of a character/
subject, those ARE the identity source: get them as files into `refs/` (ask for the
folder path — chat-pasted images are not exportable), then build every identity-
bearing generation FROM them (Seedream v5 Pro Edit conditioning for keyframes,
`image_urls` for reference-to-video). Ask whether the character is an existing
LoRA/persona. Synthetic turnaround sheets are for characters with NO refs only;
a text-anchor lookalike of a ref'd character needs explicit user sign-off first.

For each recurring subject (character, creature, monument, vehicle, prop):

1. Define a **verbatim anchor phrase** (e.g. "an astronaut in a weathered off-white
   fabric spacesuit with a boxy chest module and a round white helmet") — reused
   word-for-word in every prompt that shows the subject. Log in PLAN.md table.
2. Generate a **sheet**: one Seedream v5 Pro image, neutral light, front + 3/4 +
   profile + back of the subject on a plain ground ("character turnaround sheet,
   four views, consistent proportions, neutral grey backdrop, <anchor phrase>,
   <register unifiers>"). 2 variants, pick, save to `cast/`.
3. Upload picks (fal_client) and record URLs in PLAN.md.

Sheets feed `reference-to-video` at stage 6 and `seedream/v5/pro/edit` fixes at
stage 5. Skipping this is what produces plush-face/feline drift between shots.

## 4 · Keyframes

One job per shot in `keyframes_spec.json` → `python3 $F/bin/gen.py <spec>`.
Payload shape: prompt = register block + subject (anchor phrases verbatim) +
composition + unifiers + "No text, no lettering, no watermark."
`image_size {2520×1080}`, `num_images 2`, png, safety checker off.
Compose the frame FOR its camera move (dolly-behind wants the subject from back;
tilt-up wants paws-to-face headroom; locked money shot wants the event pre-staged).

## 5 · Frame review (Read every variant)

Pick per shot; grade against the register + beat. Fixable single defect (wrong
face, texture too soft) → `bytedance/seedream/v5/pro/edit` with the keyframe +
cast sheet as references and a one-change instruction, rather than a re-roll.
≤2 generations per keyframe total, then reshape the shot instead.

## 6 · Animate

Upload picks → `video_spec.json` → gen.py. Seedance dialect (if the
frontier-video-prompting skill is installed, read its prompt-dialects reference
before writing; the core rules follow):
motion-only prompts — do NOT re-describe the still; ONE camera move, one speed;
counted beats in prose ("For the first three seconds…" — bracket timestamps act as
hard CUTS in Seedance, avoid); end with "No captions, no on-screen text, no music."
Params: `duration` per beat table, `resolution "1080p"` (draft) , `aspect_ratio
"auto"` (inherits the still), `generate_audio false` (we own the mix),
`bitrate_mode "high"`.

- **One-off shot** → `image-to-video` with the keyframe.
- **Recurring subject in motion** → `reference-to-video` with `image_urls`:
  [keyframe, cast sheet] and the anchor phrase in the prompt.
- Run as background Bash; generate stage 8 audio while it renders.

## 7 · Clip review

```bash
ffmpeg -y -v error -i clips/<s>.mp4 -vf "fps=1,scale=500:-1,tile=4x3:padding=4:color=black" frames/<s>_sheet.png
```
Read each sheet: first frame (matches keyframe?), per-second spread (morphing,
subject drift, extra cuts?), final frame (holds under the next cut?). Name the
single failing axis; fix it (frontier-video-prompting's failure-modes reference
maps fixes if installed); ≤3 gens/clip; two non-improvements → change mechanics
(v2v edit, Kling fallback, or re-stage the beat). Keep prompt-deviations that
IMPROVE the film — flag each in the delivery notes as vetoable.

## 8 · Audio

- **Score**: `fal-ai/elevenlabs/music`, one prompt with era/instrumentation, a
  build map with timestamps aligned to the edit (impact at the money-shot cut), and
  exclusions ("no modern braams…"). `music_length_ms` = runtime + ~1 s,
  `force_instrumental true`, `output_format "pcm_44100"`. ffprobe-verify: pcm_s16le.
- **VO**: eleven-v3, voice per project (Brian = solemn default), stability ~0.4
  (0.3 whispers). Write `vo_script.json` {voN: line}, then **always**:
  `python3 $F/bin/vo_qa.py $P` — transcribes with wizper, fuzzy-matches, flags
  literal tag reads. Regenerate failures without tags.
- **SFX**: one endpoint attempt; on failure synthesize (battle-tested low rumble):
  ```bash
  ffmpeg -y -f lavfi -i "anoisesrc=color=brown:r=44100:d=10" -f lavfi -i "sine=frequency=31:r=44100:d=10" \
   -filter_complex "[0]lowpass=f=90,volume=2.2[n];[1]volume=1.4,tremolo=f=6.5:d=0.6[s];[n][s]amix=inputs=2:duration=first,afade=t=in:d=1.2,afade=t=out:st=7.5:d=2.5,alimiter=limit=0.9[out]" \
   -map "[out]" -ac 2 audio/sfx_rumble.wav
  ```
- Keep the bed minimal: score + sparse VO + 1–2 event SFX. Wind/room lives in the
  score prompt.

## 9 · Title + assembly

```bash
python3 $F/bin/title_card.py "<Title>" $P --w <clipW> --h <clipH> --dur 7
cp $F/templates/assemble.sh.template $P/assemble.sh   # scaffold already did this
# edit the EDIT ME block: clip order, VO delays (ms), rumble delay, trims
bash $P/assemble.sh
```
The template graph: concat → unify grade (eq + vignette + noise) → title concat →
VO bus → **sidechaincompress ducks score under VO** → rumble → amix → loudnorm
−14 LUFS → CRF16 archival master + WAV mix master + CRF21 delivery encode.
VO timing: place lines inside their shot, whisper-payoffs AFTER the event settles;
verify clip boundary math from the manifest durations (Seedance adds ~0.04 s).

## 10 · Verify + deliver

ffprobe duration/streams; extract 2–3 spot frames (money shot mid-event, title) and
Read them. Then send the user the delivery mp4 + DELIVERY.md containing: shot map
with VO, **defect list** (specific, per shot, including kept deviations as
vetoable), file inventory (masters, stems, payloads), spend estimate, and the
per-shot iteration menu (re-roll from payload / v2v edit / 4K bump). No quality
claims beyond "passes my frame review."

## Upgrade ladders (on request, never default)

- **4K finals**: re-run winning clip payloads with `resolution: "4k"` only.
- **Polish mix**: hand `out/mix_master.wav` + stems to a human-grade audio tool
  (e.g. Descript) for the polish pass.
- **Longer form**: chain scenes with Seedance `end_image_url` (first/last-frame
  continuity) — probe param first; keep per-scene structure identical to trailers.
