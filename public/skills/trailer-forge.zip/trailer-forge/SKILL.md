---
name: trailer-forge
description: End-to-end concept→watchable-film pipeline on fal — turns a logline or style refs into a finished conceptual movie trailer, teaser, or micro-short (≤2 min) with score, VO, SFX, grade, and title, delivered as one watchable cut plus per-shot re-roll payloads. Use whenever the user wants to MAKE a trailer, teaser, concept film, short film, promo film, or "animate this idea / these refs into a film" — even if no model or tool is named, and even if they only paste reference images with film intent. Also use for follow-ups on an existing forge project (re-roll shot 3, swap the VO, 4K the money shot, recut). Composes with the `fal` and `frontier-video-prompting` skills when installed; for a SINGLE clip or a prompt-only request, use a video-prompting or media-prompt skill instead; for music-only work, a dedicated music skill.
---

# trailer-forge

Concept → style bible → causal beats → cast sheets → keyframes → animate → audio →
assemble → deliver. Proven end-to-end (reference run: 7 shots, zero regens, ~$30,
~35 min for a ~60 s trailer).

**Prerequisites** (verify before stage 0; ask the user for locations rather than
guessing): `FAL_KEY` exported in the environment (a fal.ai API key);
`ffmpeg`/`ffprobe` on PATH; Python 3 with Pillow; `fal-client` installed in some
Python (`pip install fal-client`) for file uploads — set `FAL_PYTHON` to that
interpreter if it isn't the default `python3`.

**Layout:** `bin/` (gen.py queue runner, scaffold.sh, title_card.py, vo_qa.py) and
`templates/` ship inside this skill folder. Projects live at
`$TRAILER_FORGE_HOME/projects/<slug>` (default `~/trailer-forge/projects`) — durable
output; never leave deliverables in session scratchpad (masters are large and
scratchpad is ephemeral).

## The contract (binding, learned from real verdicts)

1. **Causality, not clips.** Shot lists are events with consequences (seek → find →
   touch → wake). A mood reel of pretty shots is the documented failure mode.
2. **Sound-first delivery.** The first artifact the user sees plays with score/VO/SFX
   mixed. Never show a silent draft; never gate obviously-required layers on approval.
3. **One decisive pass** is the default run mode. Spend budget on the risky money
   shot rather than timid iterations. Ceilings: ≤2 gens/keyframe (as
   `num_images: 2` in one call), ≤3 gens/clip, then change mechanics.
4. **Continuity is first-class even in short form.** Every recurring subject gets a
   cast sheet + verbatim anchor phrase before any keyframe renders (see pipeline.md).
5. **i2v-first.** Win the look in stills, animate with motion-only prompts. Text-to-
   video only when the model's own staging is acceptable.
6. **Titles and lockups in post, never in-model.** `bin/title_card.py` — sentence
   case, tracked; ALL-CAPS is banned taste-wise.
7. **Lossless audio chain.** Music generated/kept as PCM/WAV; ffprobe-verify every
   download; mix master exported as WAV beside the mp4.
8. **No self-certification.** Deliver "passes my frame review" + a specific per-shot
   defect list + deviations kept (flagged as vetoable). The user is reviewer of
   record.
9. **Verify live before generating.** Probe endpoint schemas (routing.md) — the
   catalog churns monthly and stale IDs 404.
10. **Identity refs are sacred.** If supplied reference images contain a character or
   subject, those exact pixels ARE the brief — pasted chat images cannot be exported,
   so STOP and get the actual files (ask for the folder path / refs/ drop) before any
   generation, then condition on them (Seedream v5 Pro Edit ≤10 refs, Seedance
   reference-to-video). A text-anchor lookalike requires the user's explicit OK,
   named as a substitution, before spend. (Battle-learned: a lookalike shipped
   without sign-off lands as a complete fail — the pipeline's whole value is
   carrying the user's creative essence.)
11. **Titles are pitches, not decisions.** Offer 3–5 registers or take the user's;
   never lock a title they haven't seen.

## Stage flow (detail + exact commands: references/pipeline.md)

| Stage | Tool | Output |
|---|---|---|
| 0 Scaffold | `bin/scaffold.sh <slug>` | project dirs + PLAN.md skeleton |
| 1 Style bible | absorb refs → registers + unifiers | PLAN.md §style |
| 2 Beats | causal shot table, ONE novel element + ONE camera move per shot | PLAN.md §shots |
| 3 Cast sheets | Seedream v5 Pro multi-view sheet per recurring subject | cast/*.png + anchors |
| 4 Keyframes | Seedream v5 Pro t2i, 2 variants, 2520×1080 | keyframes/ |
| 5 Frame review | Read every variant, pick, log defects | picks in spec |
| 6 Animate | Seedance 2.0: i2v for one-offs, **reference-to-video + cast sheet for recurring subjects**, audio off | clips/ |
| 7 Clip review | contact sheets (`fps=1,tile`) — first/spread/final frame | verdicts |
| 8 Audio | ElevenLabs-on-fal music (PCM) + v3 VO → **`bin/vo_qa.py` (wizper ASR match)**; SFX: try endpoint once, else ffmpeg synth | audio/ + QA report |
| 9 Assemble | `assemble.sh` (from template): concat, grade-unify, title, VO-bus sidechain duck, loudnorm | out/ masters + delivery |
| 10 Deliver | send delivery.mp4 + DELIVERY.md defect list + spend estimate | — |

Upgrades available on request, per-shot (never global re-runs): re-roll from its
payload JSON; **edit-not-regen** via fal-native v2v (Wan 2.7 edit-video primary,
Kling O3 edit alt — routing.md); 4K re-render of winners on the same payloads.

## When something breaks

One retry with simplified params, then **change mechanics** (different tool/layer),
never rephrase harder. Documented fallbacks in routing.md: SFX endpoint 400s →
ffmpeg-synthesized rumble; no drawtext in Homebrew ffmpeg → title_card.py; 404 →
live catalog search (`fal.ai/api/models?keywords=`).

## Read next

- `references/pipeline.md` — per-stage commands, prompt shapes, cast-sheet recipe,
  mix graph, delivery format. Read before running a project.
- `references/routing.md` — live-probed endpoints/schemas (dated), probe ritual,
  pricing, fallback map. Re-probe anything older than ~30 days.
- Companion skills (compose when installed, otherwise this skill is self-sufficient):
  `fal` (key location, clients, LoRA configs), `frontier-video-prompting` (prompt
  dialects, failure classes, review discipline), and a lyric/phonetics or Suno-style
  music skill when the score needs lyrics instead of ElevenLabs instrumental.
